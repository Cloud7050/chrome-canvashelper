/* [Exports] */
export const TAG_PROCESSED = "tag-processed";

export const FileStatus = {
	NEW: "new",
	DOWNLOADED_MODIFIED: "downloadedModified",
	DOWNLOADED: "downloaded"
};
